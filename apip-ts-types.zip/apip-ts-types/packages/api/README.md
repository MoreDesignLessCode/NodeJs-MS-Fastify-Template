# API Program Typescript Types - API

Types that are leveraged in API Program Typescript projects for APIs

## Running unit tests

Run `nx test api` to execute the unit tests via [Jest](https://jestjs.io).

## Running lint

Run `nx lint api` to execute the lint via [ESLint](https://eslint.org/).
