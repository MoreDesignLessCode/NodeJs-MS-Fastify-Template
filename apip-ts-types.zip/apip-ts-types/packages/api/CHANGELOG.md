## [1.0.8](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.7...api-v1.0.8) (2023-02-27)


### Bug Fixes

* **api:** remove main ([2fcbae3](https://github.com/procter-gamble/apip-ts-types/commit/2fcbae3df336f308b606f60d2565c2063c436264))

## [1.0.7](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.6...api-v1.0.7) (2023-02-24)

### Bug Fixes

- **api:** update exports to chained approach ([3c71da8](https://github.com/procter-gamble/apip-ts-types/commit/3c71da89c3ef516cdc0594980124ebd58d6008ce))
- **api:** update types to union fastify ([4ca16e4](https://github.com/procter-gamble/apip-ts-types/commit/4ca16e4fd07b8795022fef138205a655e0fdb3e8))

## [1.0.6](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.5...api-v1.0.6) (2023-02-24)

### Bug Fixes

- **api:** update default fastify impl to expose instance ([0c29a58](https://github.com/procter-gamble/apip-ts-types/commit/0c29a5869f3c8c476e433266ca993d1a24185fa3))
- **api:** update undefined property to new property ([64ecad1](https://github.com/procter-gamble/apip-ts-types/commit/64ecad1970647eef25a4e21985861029f10acc94))

## [1.0.5](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.4...api-v1.0.5) (2023-02-24)

### Bug Fixes

- **api:** make Request optional on Default Context ([3e0ea0c](https://github.com/procter-gamble/apip-ts-types/commit/3e0ea0c1a47ebb593a5d4660e67a616ec738482a))

## [1.0.4](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.3...api-v1.0.4) (2023-02-23)

### Bug Fixes

- **api:** update rexports ([d30f0e6](https://github.com/procter-gamble/apip-ts-types/commit/d30f0e6cd3104f0f05ae5851d53b8b63225ed941))

## [1.0.3](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.2...api-v1.0.3) (2023-02-23)

### Bug Fixes

- **api:** export DefaultRequestContext ([b4f6c73](https://github.com/procter-gamble/apip-ts-types/commit/b4f6c730f850a687dfcbd069d7a052fe860aa29b))
- **api:** export IRequestHandler ([ce5ddf2](https://github.com/procter-gamble/apip-ts-types/commit/ce5ddf2d6f3e834c1a4a7d849272d74aa9d0ec0c))
- **api:** update exports of interface and impl ([819e1d1](https://github.com/procter-gamble/apip-ts-types/commit/819e1d181229d1752aa1b9d422e3aacd355f50b3))

## [1.0.2](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.1...api-v1.0.2) (2023-02-23)

### Bug Fixes

- **api:** fix constructor typo, update provider name to indicate fastify, add test ([281a611](https://github.com/procter-gamble/apip-ts-types/commit/281a611764dd0e1bd9d1f26edf7af77a9d71ae8f))

## [1.0.1](https://github.com/procter-gamble/apip-ts-types/compare/api-v1.0.0...api-v1.0.1) (2023-02-23)

### Bug Fixes

- **api:** update types index ([493221f](https://github.com/procter-gamble/apip-ts-types/commit/493221f52c020f608c3258e1f11dfddaf9bf19ab))

# 1.0.0 (2023-02-22)

### Bug Fixes

- **api:** add index exports for package ([3bbe258](https://github.com/procter-gamble/apip-ts-types/commit/3bbe258d84ee8f390fc86b63e3dd32a438a2b18e))
- **api:** fixed linting errors on types, explicit any, etc ([6bf5496](https://github.com/procter-gamble/apip-ts-types/commit/6bf54965de2ab5bf4a2fc40b36b2620f066dcf8a))
- **api:** update generic types, update server type ([5b50c39](https://github.com/procter-gamble/apip-ts-types/commit/5b50c3982843b43beb324ac420367425201f8eac))
- **api:** update licenses ([e98dcdc](https://github.com/procter-gamble/apip-ts-types/commit/e98dcdc988e45f4846ff7271ce758fd77c246131))
