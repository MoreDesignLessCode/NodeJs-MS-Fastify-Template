module.exports = {
  extends: 'semantic-release-npm-github-publish',
};
