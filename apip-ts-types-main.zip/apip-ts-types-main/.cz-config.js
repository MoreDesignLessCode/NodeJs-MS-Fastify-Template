module.exports = {
  path: '@commitlint/cz-commitlint',
};
