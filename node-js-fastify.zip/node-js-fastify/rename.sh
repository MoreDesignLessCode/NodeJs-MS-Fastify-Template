find . -type f -not -path '*/\.*' -exec sed -i 's/person/\$\{\{values\.resource\}\}/g' {} +
find . -type f -not -path '*/\.*' -exec sed -i 's/Person/\$\{\{values\.resource\}\}/g' {} +
find . -type f -not -path '*/\.*' -exec sed -i 's/PERSON/\$\{\{values\.resource\}\}/g' {} +