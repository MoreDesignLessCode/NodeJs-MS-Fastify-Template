export function sdk(): string {
  return 'sdk';
}
