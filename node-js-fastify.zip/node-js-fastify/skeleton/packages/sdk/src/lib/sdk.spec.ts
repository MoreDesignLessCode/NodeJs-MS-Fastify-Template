import { sdk } from './sdk';

describe('sdk', () => {
  it('should work', () => {
    expect(sdk()).toEqual('sdk');
  });
});
