export * from './lib/${{values.resource}}';
