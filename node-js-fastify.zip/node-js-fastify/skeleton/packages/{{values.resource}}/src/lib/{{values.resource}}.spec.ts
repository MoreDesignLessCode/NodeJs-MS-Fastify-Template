import { ${{values.resource}} } from './${{values.resource}}';

describe('${{values.resource}}', () => {
  it('should work', () => {
    expect(${{values.resource}}()).toEqual('${{values.resource}}');
  });
});
