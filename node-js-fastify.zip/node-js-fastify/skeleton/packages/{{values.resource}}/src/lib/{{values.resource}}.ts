export function ${{values.resource}}(): string {
  return '${{values.resource}}';
}
