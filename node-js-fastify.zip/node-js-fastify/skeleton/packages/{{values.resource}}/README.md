# ${{values.resource}}

This is the main package for the ${{values.resource}} domain interface. This will be a 
publishable library where the index will export the following:


|Export | Signature |
|:---|:---|
| `PersonRouter` | `PersonRouter(handler: PersonHandler)` |
| `PersonHandler`| `PersonHandler(service: PersonService)` |
| `PersonService`| `PersonService(repository: PersonRepository)` |
| `PersonRepository` | `PersonRepository(storageProvider: PersonStorageProvider)`|
| `PersonStorageProvider`| `new PersonStorageProvider()` |

This is being built in a hexagonal architecture ("adapters & ports") fashion
to enable a maintainable and evolvable capability.



## Running unit tests

Run `nx test ${{values.resource}}` to execute the unit tests via [Jest](https://jestjs.io).

## Running lint

Run `nx lint ${{values.resource}}` to execute the lint via [ESLint](https://eslint.org/).
