[Backstage Software Templates](https://backstage.io/docs/features/software-templates/) are used to create new software components through Backstage. These templates are intended as a starting point to build on for different use cases. 

# software-template for NodeJS microservice (DOI) using fastify
A DOI is the published interface for all personas (public, private, partner) to leverage. This is considered the conanical model that represents a resource within a particular domain.